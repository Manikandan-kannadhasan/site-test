const initialState = {
    selectedUserDetails: ""    
  };
  
  const reducer = (state = initialState, action) => {
    const newState = { ...state };
  
    switch (action.type) {
      case "SET_USER_DETAILS":
        newState.selectedUserDetails = action.value;
        break;     
      default:
        newState.show = ""
    }
    return newState;
  };
  
  export default reducer;
  