import React from 'react'
import { Route, BrowserRouter as Router} from 'react-router-dom'
import { Container } from 'react-bootstrap'
import App from './App'
import Header from './components/layout/Header'
import Navbar from './components/layout/Navigation'
import About from './components/pages/about'
import Contact from './components/pages/contact'
import reducer from "./redux/index";
import { Provider } from "react-redux";
import { createStore } from "redux";

const store = createStore(reducer);

const Routing = (
  <Provider store={store}>
    <Router>
      <div className="App">
        <Header />
        <Navbar />      
        <Container>
          <Route exact path="/" component={App} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
        </Container>
      </div>
    </Router>
  </Provider>
)
  
 export default Routing;