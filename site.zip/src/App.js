import React from 'react';
import './App.css';
import Home from './components/layout/Body'

function App() {
  return (
    <React.Fragment>
      <Home />
   </React.Fragment>
  );
}

export default App;
