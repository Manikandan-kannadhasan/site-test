export default function validate(values) {
    let errors = {};   
    if (!values.firstName) {
      errors.firstName = 'First Name is required';
    } 
    if (!values.lastName) {
        errors.lastName = 'Last Name is required';
    }
    if (!values.terms) {
      errors.terms = 'Must accept terms and condition';
  }
     if (!values.email) {
      errors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
      errors.email = 'Email address is invalid';
    }
    return errors;
  };
  