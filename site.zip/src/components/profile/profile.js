import React, { useState, useEffect } from 'react';
import {Button} from 'react-bootstrap'
import { connect } from 'react-redux';
import validate from '../../common/validation'

const Profile = (props) => {
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (Object.keys(errors).length === 0 && isSubmitting) {
      submit();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps 
  }, [errors]);

  const handleSubmit = (event) => {
    if (event) event.preventDefault();
    setErrors(validate(values));
    setIsSubmitting(true);
  };

  //Set Redux value while loading
  const mount = () => {
    setValues(values => ({ ...values, firstName: values.firstName ? values.firstName : props.selectedUserDetails && props.selectedUserDetails[0] }));
    setValues(values => ({ ...values, lastName: values.lastName ? values.lastName : props.selectedUserDetails && props.selectedUserDetails[1] }));
    setValues(values => ({ ...values, email: values.email ? values.email : props.selectedUserDetails && props.selectedUserDetails[2] }));
  }
  useEffect(mount, [props.selectedUserDetails]); 

  // clear form value when tab change
  useEffect(() => {
    props.selectedTab && setValues(values => ({ ...values, firstName: '', lastName: '', email: '', terms: ''}));   
  }, [props.selectedTab]);

   const handleChange = (event) => {
    event.persist();
    let eventValue = event.target.type === "checkbox" ? event.target.checked : event.target.value;
    setValues(values => ({ ...values, [event.target.name]: eventValue }));
  };
    
  const submit = () => {
      props.sendSelectedRowDetails();
      props.setTab("users");
      setValues(values => ({ ...values, firstName: '', lastName: '', email: '', terms: ''}));
      console.log(`Successfully submited!, first Name: ${values.firstName}, last Name: ${values.lastName}, Email: ${values.email}`);
  }

  return (
      <form className="profile-form" onSubmit={handleSubmit} noValidate>              
        <div className="field col-6">
          <label className="label">First Name</label>
          <div className="control">
            <input className={`input ${errors.firstName && 'is-danger'}`} type="firstName" name="firstName" onChange={handleChange} value={values.firstName || ''} required />
          </div>
          {errors.firstName && ( <p className="help is-danger">{errors.firstName}</p> )}
        </div>

        <div className="field col-6">
          <label className="label">Last Name</label>
          <div className="control">
            <input className={`input ${errors.lastName && 'is-danger'}`} type="lastName" name="lastName" onChange={handleChange} value={values.lastName || ''} required />
          </div>
          {errors.lastName && (<p className="help is-danger">{errors.lastName}</p>)}
        </div>

        <div className="field col-6">
          <label className="label">Email Address</label>
          <div className="control">
            <input autoComplete="off" className={`input ${errors.email && 'is-danger'}`} type="email" name="email" onChange={handleChange} value={values.email || ''} required />
            {errors.email && ( <p className="help is-danger">{errors.email}</p>)}
          </div>
        </div>

        <div className="col-12 field padding-0">
          <div className="field col-1 padding-0"> 
          <input type="checkbox" name="terms" checked={values.terms || ''}  value={values.terms || ''} onChange={handleChange} required />
          </div>
          <div className="field col-6 padding-0">          
          <label>Terms and Conditions</label>
          {errors.terms && ( <p className="help is-danger">{errors.terms}</p>)}
          </div>
        </div>

        <div className="field col-12 margin-0">
          <Button type="submit" variant="primary">Submit</Button>
        </div>
      </form>
  );
}

const mapStateToProps = state => {
  return {
    selectedUserDetails: state.selectedUserDetails
  };
};

const mapDispachToProps = dispatch => {
  return {
      sendSelectedRowDetails: (selected) =>
          dispatch({ type: "SET_USER_DETAILS", value: selected })
  };
};

export default connect(mapStateToProps, mapDispachToProps)(Profile);
