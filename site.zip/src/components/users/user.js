import React, { useState, useEffect } from 'react' 
import {Table} from 'react-bootstrap'
import { connect } from 'react-redux';

function Users(props) {
  const [userData, setUserData] = useState([]);

  useEffect(() => {
      // send HTTP request
      fetch('https://reqres.in/api/users?page=2')
      .then(res => res.json())
      .then(data => setUserData(data))
      .catch(() => console.log('something went wrong'))
  }, []);

  const selectRow = rowIndex => {    
    props.setTab('profile');
    let getApiData = userData['data'];
    let selectedRow = getApiData[rowIndex];
    let selectedRowData = [selectedRow.first_name, selectedRow.last_name, selectedRow.email];
    props.sendSelectedRowDetails(selectedRowData);
   }

  return (     
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
        {userData['data'] && userData['data'].map((listValue, index) => {
          return (
            <tr key={index} onClick={selectRow.bind(this, index)}>
              <td>{listValue.first_name}</td>
              <td>{listValue.last_name}</td>
              <td>{listValue.email}</td>
            </tr>
            );
          })
        }
      </tbody>
    </Table>
  );
}

const mapDispachToProps = dispatch => {
  return {
      sendSelectedRowDetails: (selected) =>
          dispatch({ type: "SET_USER_DETAILS", value: selected })
  };
};

export default connect(null, mapDispachToProps)(Users);
