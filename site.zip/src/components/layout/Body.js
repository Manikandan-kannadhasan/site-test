import React, { useState, useEffect } from "react";
import { Tabs, Tab } from "react-bootstrap";
import Users from "../users/user";
import Profile from "../profile/profile";

function Body(props) {
  const [key, setKey] = useState("users");
  const [clear, setClear] = useState(false);
  
  const clearValue= (k) => {
    setKey(k);
  }

  const setActiveTab = (value) => {
    setKey(value);
  };

  useEffect(() => {
    setClear(!clear);
    // eslint-disable-next-line react-hooks/exhaustive-deps 
  }, [key]);

  return (
    <React.Fragment>
      <h1>Home</h1>
      <Tabs 
        transition={false}
        id="controlled-tab-example"
        activeKey={key}
        onSelect={(k) => clearValue(k)}
      >
        <Tab eventKey="users" title="User List">
          <Users setTab={setActiveTab}  />
        </Tab>
        <Tab eventKey="profile" title="User Profile">
          <Profile setTab={setActiveTab} selectedTab={clear} />
        </Tab>
      </Tabs>
    </React.Fragment>
  );
}

export default Body;
