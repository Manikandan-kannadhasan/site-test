import React from 'react';
import {Navbar, Form} from 'react-bootstrap'

function Header() {
    return (
      <div>
        <Navbar className="header-navbar bg-dark justify-content-between">
            <Navbar.Brand href="/">Company Name</Navbar.Brand>
            <Form inline> Michael Lawson</Form>            
        </Navbar>
      </div>
    );
  };

export default Header;