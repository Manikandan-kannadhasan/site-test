import React from 'react';
import {Navbar, Nav} from 'react-bootstrap'
import { NavLink } from 'react-router-dom';

function Navigation() {
    return (
      <Navbar className="custom-navbar" bg="primary" expand="lg">
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <NavLink exact activeClassName="active" to="/"><img alt="Home"  src={require('../../images/home.png')} /></NavLink>
            <NavLink activeClassName="active" to="/about"><img alt="About"  src={require('../../images/about.png')} /></NavLink>
            <NavLink activeClassName="active" to="/contact"><img alt="Contact"  src={require('../../images/contact.png')} /></NavLink>
         </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  };

export default Navigation;